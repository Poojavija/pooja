package com.dsms.app.constants;

public enum PickupType {

    STORE,
    HOME_DELIVERY
}

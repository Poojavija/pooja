package com.dsms.app.constants;

public enum CartItemStatus {

    ACTIVE,
    INACTIVE
}

package com.dsms.app.config;

public class Config {
}

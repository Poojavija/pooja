package com.dsms.app.constants;

public enum OrderStatus {

    PLACED,
    IN_PROGRESS,
    READY_FOR_DELIVERY,
    SUCCESS
}

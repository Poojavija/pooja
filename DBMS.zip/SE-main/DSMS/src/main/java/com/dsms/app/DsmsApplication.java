package com.dsms.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DsmsApplication.class, args);
    }

}
